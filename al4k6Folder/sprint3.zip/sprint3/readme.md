  Our goal was to create a easy to view website about certain parts of augur. It gives detailed information about the augur project and its repos and gives insight into how they were created. It has 3 seperate tabs that run different apis that print out to graphs in an easy to read format. To run our project, run any of the .html files in sprint 3, it will give you access to all of the pages through the nav bar. The dropdown menu on the left is selected first which will then populate the dropdown on the right, then the go button loads the rest. It may take some time to load as some of the repo groups contain many repos.





change 1: created sprint3 folder

change 2: added dynamic dropdown for the second dropdown.

change 3: added css to tell user to wait a sec for the list to populate

change 4: Found api endpoints for a couple of the options

change 5: got library for charts

change 6: implement charts

change 7: implement the api enpoints into the charts
