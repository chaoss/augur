\i 1-schema.sql
\i 2-augur_data.sql 
\i 3-augur_operations.sql 
\i 4-spdx.sql
\i 5-seed-data.sql 
