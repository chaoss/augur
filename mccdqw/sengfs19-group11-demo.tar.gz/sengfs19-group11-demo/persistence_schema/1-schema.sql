-- ----------------------------
CREATE SCHEMA augur_data;
CREATE SCHEMA augur_operations;
CREATE SCHEMA spdx;
-- create the schemas
-- -----------------------