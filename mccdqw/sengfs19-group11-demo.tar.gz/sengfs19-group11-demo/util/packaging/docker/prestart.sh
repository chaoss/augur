#!bash
(augur -u &)