module.exports = {
  'extends': [
    '@vue/typescript'
  ],
  parserOptions: {
    parser: '@typescript-eslint/parser'
  }
}
