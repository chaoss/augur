declare module '*.vue' {
  import Vue from 'vue';
  export default Vue;
}

declare module 'shards-vue';
declare module 'vue-vega';
declare module 'svgsaver';