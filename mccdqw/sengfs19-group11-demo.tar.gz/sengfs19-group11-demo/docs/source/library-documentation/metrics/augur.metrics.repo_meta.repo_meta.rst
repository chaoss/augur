augur.metrics.repo\_meta.repo\_meta
===================================

.. automodule:: augur.metrics.repo_meta.repo_meta

   
   
   .. rubric:: Functions

   .. autosummary::
   
      annual_lines_of_code_count_ranked_by_new_repo_in_repo_group
      annual_lines_of_code_count_ranked_by_repo_in_repo_group
      cii_best_practices_badge
      code_changes
      code_changes_lines
      create_repo_meta_metrics
      fork_count
      forks
      languages
      license_count
      license_coverage
      license_declared
      lines_of_code_commit_counts_by_calendar_year_grouped
      sbom_download
      stars
      stars_count
      sub_projects
      watchers
      watchers_count
   
   

   
   
   

   
   
   