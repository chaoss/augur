augur.metrics.platform.platform
===============================

.. automodule:: augur.metrics.platform.platform

   
   
   .. rubric:: Functions

   .. autosummary::
   
      create_platform_metrics
   
   

   
   
   

   
   
   