augur.metrics.commit.commit
===========================

.. automodule:: augur.metrics.commit.commit

   
   
   .. rubric:: Functions

   .. autosummary::
   
      annual_commit_count_ranked_by_new_repo_in_repo_group
      annual_commit_count_ranked_by_repo_in_repo_group
      committers
      create_commit_metrics
   
   

   
   
   

   
   
   