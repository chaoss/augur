augur.metrics.pull\_request.pull\_request
=========================================

.. automodule:: augur.metrics.pull_request.pull_request

   
   
   .. rubric:: Functions

   .. autosummary::
   
      create_pull_request_metrics
      pull_request_acceptance_rate
      pull_requests_merge_contributor_new
      review_duration
      reviews
      reviews_accepted
      reviews_declined
   
   

   
   
   

   
   
   