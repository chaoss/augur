augur.metrics.insight.insight
=============================

.. automodule:: augur.metrics.insight.insight

   
   
   .. rubric:: Functions

   .. autosummary::
   
      create_insight_metrics
      top_insights
   
   

   
   
   

   
   
   