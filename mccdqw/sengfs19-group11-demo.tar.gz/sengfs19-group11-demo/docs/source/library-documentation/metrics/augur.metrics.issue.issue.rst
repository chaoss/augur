augur.metrics.issue.issue
=========================

.. automodule:: augur.metrics.issue.issue

   
   
   .. rubric:: Functions

   .. autosummary::
   
      abandoned_issues
      average_issue_resolution_time
      closed_issues_count
      create_issue_metrics
      issue_backlog
      issue_comments_mean
      issue_comments_mean_std
      issue_duration
      issue_participants
      issue_throughput
      issues_active
      issues_closed
      issues_closed_resolution_duration
      issues_first_time_closed
      issues_first_time_opened
      issues_maintainer_response_duration
      issues_new
      issues_open_age
      open_issues_count
   
   

   
   
   

   
   
   