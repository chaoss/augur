augur.augurplugin.AugurPlugin
=============================

.. currentmodule:: augur.augurplugin

.. autoclass:: AugurPlugin

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AugurPlugin.__init__
      ~AugurPlugin.create_routes
      ~AugurPlugin.update
   
   

   
   
   