augur.server.Server
===================

.. currentmodule:: augur.server

.. autoclass:: Server

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Server.__init__
      ~Server.addGitMetric
      ~Server.addMetric
      ~Server.addTimeseries
      ~Server.flaskify
      ~Server.transform
      ~Server.updateMetricMetadata
   
   

   
   
   