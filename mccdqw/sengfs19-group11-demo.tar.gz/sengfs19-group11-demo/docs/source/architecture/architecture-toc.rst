Architecture
============


.. toctree::
   :maxdepth: 1

   architecture
   data-model
   frontend
