Data Collection
----------------

This section details how to use Augur's built-in data collection workers.

.. toctree::
   :maxdepth: 1

   starting-collection-workers
   augur.config.json-explained
   worker-details

**THIS SECTION IS UNDER CONSTRUCTION.**

If you have questions or would like to help please open an issue on GitHub_.

.. _GitHub: https://github.com/chaoss/augur


   
