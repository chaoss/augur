augur_worker_github
===================

.. image:: https://img.shields.io/pypi/v/augur_worker_github.svg
    :target: https://pypi.python.org/pypi/augur_worker_github
    :alt: Latest PyPI version

.. image:: False.png
   :target: False
   :alt: Latest Travis CI build status

Augur Worker that collects GitHub data

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`augur_worker_github` was written by `Augur Team <s@goggins.com>`_.
