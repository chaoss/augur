# Sample Test passing with nose and pytest

def test_pass():
    assert True, "dummy sample test"
