
def create_experimental_routes(server):

    metrics = server._augur.metrics


