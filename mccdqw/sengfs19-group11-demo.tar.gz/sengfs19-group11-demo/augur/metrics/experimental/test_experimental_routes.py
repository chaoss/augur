import requests
import pytest

@pytest.fixture(scope="session")
def metrics():
    pass
