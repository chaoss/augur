
def create_platform_routes(server):

    metrics = server._augur.metrics


