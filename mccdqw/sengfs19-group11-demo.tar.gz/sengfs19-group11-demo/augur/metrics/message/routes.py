
def create_message_routes(server):

    metrics = server._augur.metrics


