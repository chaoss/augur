#SPDX-License-Identifier: MIT
"""
Metrics that provide data about messages (of any form) & their associated activity
"""
