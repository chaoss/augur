#SPDX-License-Identifier: MIT

import os
ROOT_AUGUR_DIRECTORY = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
