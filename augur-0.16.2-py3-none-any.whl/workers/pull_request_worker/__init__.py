#SPDX-License-Identifier: MIT
"""gh_pr_worker - Augur Worker that collects GitHub Pull Request data"""

__version__ = '0.0.1'
__author__ = 'Augur Team <s@goggins.com>'
__all__ = []
