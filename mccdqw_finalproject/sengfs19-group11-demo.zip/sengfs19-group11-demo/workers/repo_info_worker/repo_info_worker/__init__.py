"""gh_repo_info_worker - Augur Worker that collects GitHub Repo Info data"""

__version__ = '0.0.0'
__author__ = 'Augur Team <s@goggins.com>'
__all__ = []
