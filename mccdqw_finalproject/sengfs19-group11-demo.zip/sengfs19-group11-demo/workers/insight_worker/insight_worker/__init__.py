"""augur_worker_github - Augur Worker that collects GitHub data"""

__version__ = '0.0.2'
__author__ = 'Augur Team <s@goggins.com>'
__all__ = []
