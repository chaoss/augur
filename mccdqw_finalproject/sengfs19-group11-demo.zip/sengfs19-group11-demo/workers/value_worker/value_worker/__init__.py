"""value_worker - Augur Worker that collects value data"""

__version__ = '0.1.0'
__author__ = 'Augur Team <s@goggins.com>'
__all__ = []
