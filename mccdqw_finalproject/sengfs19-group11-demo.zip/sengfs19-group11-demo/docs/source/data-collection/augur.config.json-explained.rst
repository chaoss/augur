The augur.config.json File
================================

