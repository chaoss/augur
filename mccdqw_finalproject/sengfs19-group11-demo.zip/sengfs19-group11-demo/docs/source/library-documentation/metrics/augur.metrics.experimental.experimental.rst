augur.metrics.experimental.experimental
=======================================

.. automodule:: augur.metrics.experimental.experimental

   
   
   .. rubric:: Functions

   .. autosummary::
   
      create_experimental_metrics
   
   

   
   
   

   
   
   