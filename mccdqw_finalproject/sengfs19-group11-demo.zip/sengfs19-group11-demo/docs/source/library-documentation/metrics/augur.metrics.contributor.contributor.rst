augur.metrics.contributor.contributor
=====================================

.. automodule:: augur.metrics.contributor.contributor

   
   
   .. rubric:: Functions

   .. autosummary::
   
      contributors
      contributors_new
      create_contributor_metrics
      lines_changed_by_author
      top_committers
   
   

   
   
   

   
   
   