augur.metrics.util.util
=======================

.. automodule:: augur.metrics.util.util

   
   
   .. rubric:: Functions

   .. autosummary::
   
      aggregate_summary
      create_util_metrics
      downloaded_repos
      get_group_by_name
      get_issues
      get_repo_by_git_name
      get_repo_by_name
      get_repos_for_dosocs
      repo_groups
      repos_in_repo_groups
   
   

   
   
   

   
   
   