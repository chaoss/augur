augur.cli.db
============

.. automodule:: augur.cli.db

   
   
   .. rubric:: Functions

   .. autosummary::
   
      execute
   
   

   
   
   

   
   
   