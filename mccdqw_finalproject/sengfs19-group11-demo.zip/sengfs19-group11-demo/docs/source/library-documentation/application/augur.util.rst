augur.util
==========

.. automodule:: augur.util

   
   
   .. rubric:: Functions

   .. autosummary::
   
      annotate
      getFileID
      get_cache
      get_data_path
   
   

   
   
   

   
   
   