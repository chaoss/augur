augur.housekeeper.housekeeper.Housekeeper
=========================================

.. currentmodule:: augur.housekeeper.housekeeper

.. autoclass:: Housekeeper

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Housekeeper.__init__
      ~Housekeeper.join_updates
      ~Housekeeper.prep_jobs
      ~Housekeeper.schedule_updates
      ~Housekeeper.shutdown_updates
      ~Housekeeper.update_all
      ~Housekeeper.updater_process
   
   

   
   
   