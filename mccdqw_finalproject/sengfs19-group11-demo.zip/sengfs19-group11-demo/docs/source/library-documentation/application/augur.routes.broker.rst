augur.routes.broker
===================

.. automodule:: augur.routes.broker

   
   
   .. rubric:: Functions

   .. autosummary::
   
      create_broker_routes
      send_task
   
   

   
   
   

   
   
   