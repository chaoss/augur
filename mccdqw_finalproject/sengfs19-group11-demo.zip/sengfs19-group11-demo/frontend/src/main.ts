/* tslint:disable */
require('./Augur').default();